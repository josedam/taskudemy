export interface JwtAccessToken {
    accessToken: string;
}